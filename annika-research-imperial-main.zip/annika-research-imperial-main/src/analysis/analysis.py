"""Analysis utilities for probing type effectiveness analysis."""

from rich import print
from rich.table import Table
from rich.console import Console
from .utils import get_significance_info, print_significance_legend, calculate_effectiveness_metrics
from pathlib import Path
from donware import banner
import pandas as pd


def _render_table(effectiveness: Table, console: Console) -> None:
    console.print(effectiveness)


def _build_effectiveness_table(effectiveness_df: "pd.DataFrame", title: str) -> Table:
    table = Table(title=title)
    table.add_column("Rank", style="bold white", width=5)
    table.add_column("Probing Type", style="cyan", width=20)
    table.add_column("Count", style="white", width=6)
    table.add_column("Mean Depth", style="bold green", width=10)
    table.add_column("P (FDR)", style="bold red", width=9)
    table.add_column("Significance", style="bold yellow", width=12)
    table.add_column("Std Dev", style="yellow", width=8)
    table.add_column("Median", style="magenta", width=8)
    table.add_column("Avg Response Length", style="blue", width=15)

    for rank, (probing_type, stats) in enumerate(effectiveness_df.iterrows(), 1):
        sig_level, sig_color = get_significance_info(stats.get("p_adj", stats["p_value"]))
        table.add_row(
            f"{rank}",
            probing_type,
            str(int(stats["count"])),
            f"{stats['mean_depth']:.3f}",
            f"{(stats.get('p_adj', stats['p_value'])):.3f}",
            f"[{sig_color}]{sig_level}[/{sig_color}]",
            f"{stats['std_depth']:.3f}",
            f"{stats['median_depth']:.3f}",
            f"{stats['avg_response_length']:.0f}",
        )
    return table


def analyze_probing_effectiveness(df, min_n_for_test: int = 5):
    """Analyze which probing types lead to deepest responses, printing three tables (All, Human, AI).

    min_n_for_test controls the minimum focal group size required to run significance tests.
    """
    console = Console()

    print(f"\n[bold blue]RESEARCH QUESTION 2: Which Probing Types Lead to Deeper Responses?[/bold blue]")
    banner("-")

    # Compute metrics
    effectiveness_all = calculate_effectiveness_metrics(df, min_n_for_test=min_n_for_test)
    effectiveness_human = calculate_effectiveness_metrics(df[df["conversation_nature"] == "human"], min_n_for_test=min_n_for_test) if (df["conversation_nature"] == "human").any() else effectiveness_all.iloc[0:0]
    effectiveness_ai = calculate_effectiveness_metrics(df[df["conversation_nature"] == "ai"], min_n_for_test=min_n_for_test) if (df["conversation_nature"] == "ai").any() else effectiveness_all.iloc[0:0]

    # Render three tables
    _render_table(_build_effectiveness_table(effectiveness_all, "Probing Type Effectiveness (All)"), console)
    _render_table(_build_effectiveness_table(effectiveness_human, "Probing Type Effectiveness (Human only)"), console)
    _render_table(_build_effectiveness_table(effectiveness_ai, "Probing Type Effectiveness (AI only)"), console)

    # Significance legend once
    print_significance_legend()

    # Persist CSVs
    results_dir = Path("results")
    results_dir.mkdir(parents=True, exist_ok=True)
    (results_dir / "effectiveness_by_probing_type.csv").write_text("")
    effectiveness_all.to_csv(results_dir / "effectiveness_by_probing_type.csv")
    effectiveness_human.to_csv(results_dir / "effectiveness_by_probing_type_human.csv")
    effectiveness_ai.to_csv(results_dir / "effectiveness_by_probing_type_ai.csv")
    print(f"[green]Saved effectiveness tables to '{results_dir}'[/green]")

    return effectiveness_all


def generate_insights(df, effectiveness):
    """Generate key insights and recommendations."""
    print(f"\n[bold green]KEY INSIGHTS: What Probing Types Lead to Deeper Responses?[/bold green]")
    banner("-")

    # Top performers
    top_3 = effectiveness.head(3)
    print(f"[bold yellow]TOP 3 MOST EFFECTIVE PROBING TYPES:[/bold yellow]")
    for i, (probing_type, stats) in enumerate(top_3.iterrows(), 1):
        print(f"  {i}. {probing_type}")
        print(f"      Mean depth: {stats['mean_depth']:.3f} (n={int(stats['count'])})")
        print(f"      Average response length: {stats['avg_response_length']:.0f} characters")
        print("")

    # Bottom performers
    bottom_3 = effectiveness.tail(3)
    print(f"[bold red]LEAST EFFECTIVE PROBING TYPES:[/bold red]")
    for i, (probing_type, stats) in enumerate(bottom_3.iterrows(), 1):
        print(f"  {i}. {probing_type}: Mean depth = {stats['mean_depth']:.3f} (n={int(stats['count'])})")

    # Statistical insights
    high_depth = df[df["response_depth"] == 3]
    if len(high_depth) > 0:
        print(f"\n[bold blue]DEPTH LEVEL 3 (HIGHEST) ANALYSIS:[/bold blue]")
        depth_3_types = high_depth["probing_type"].value_counts().head(5)
        for probing_type, count in depth_3_types.items():
            percentage = (count / len(high_depth)) * 100
            print(f"  {probing_type}: {count} instances ({percentage:.1f}% of all depth-3 responses)")

    # Conversation nature differences
    print(f"\n[bold blue]HUMAN vs AI DIFFERENCES:[/bold blue]")
    nature_comparison = df.groupby(["conversation_nature", "probing_type"])["response_depth"].mean().unstack(fill_value=0)
    if "human" in nature_comparison.index and "ai" in nature_comparison.index:
        for probing_type in effectiveness.head(5).index:
            if probing_type in nature_comparison.columns:
                human_depth = nature_comparison.loc["human", probing_type] if "human" in nature_comparison.index else 0
                ai_depth = nature_comparison.loc["ai", probing_type] if "ai" in nature_comparison.index else 0
                if human_depth > 0 and ai_depth > 0:
                    diff = human_depth - ai_depth
                    better = "Human" if diff > 0 else "AI"
                    print(f"  {probing_type}: {better} better by {abs(diff):.3f} depth points")

    # Recommendations
    print(f"\n[bold green]RECOMMENDATIONS FOR DEEPER RESPONSES:[/bold green]")
    print(f"  1. Use '{top_3.index[0]}' more frequently - highest mean depth ({top_3.iloc[0]['mean_depth']:.3f})")
    if len(top_3) > 1:
        print(f"  2. Incorporate '{top_3.index[1]}' as secondary strategy")
    if len(top_3) > 2:
        print(f"  3. Consider '{top_3.index[2]}' for sustained engagement")

    # Length insights
    avg_length_high = df[df["response_depth"] >= 2.5]["response_length"].mean()
    avg_length_low = df[df["response_depth"] <= 1.5]["response_length"].mean()
    if avg_length_high > avg_length_low:
        print(f"  4. Longer responses correlate with depth (high-depth avg: {avg_length_high:.0f} vs low-depth: {avg_length_low:.0f} chars)")

    return {"top_probing_types": top_3.index.tolist(), "effectiveness_scores": top_3["mean_depth"].tolist(), "sample_sizes": top_3["count"].tolist()}
