"""Statistical analysis utilities for probing type analysis."""

import warnings
import sys
from pathlib import Path
import numpy as np
import statsmodels.formula.api as smf
import scipy.stats as stats
from rich import print
from .utils import get_significance_info, filter_groups_by_size, scale_columns
from src.utils.fix_categorical_variables import prepare_data_for_mixed_effects


def run_anova_test(df):
    """Run one-way ANOVA test on probing types."""
    probing_types = df["probing_type"].unique()
    depth_groups = [df[df["probing_type"] == pt]["response_depth"].dropna().values for pt in probing_types]
    depth_groups = [group for group in depth_groups if len(group) > 0]

    if len(depth_groups) > 1:
        f_stat, p_value = stats.f_oneway(*depth_groups)
        print(f"One-way ANOVA: F={f_stat:.3f}, p={p_value:.3f}")
        print("Significant differences found between probing types!" if p_value < 0.05 else "No significant differences found between probing types")

        return f_stat, p_value
    return None, None


def run_mixed_effects_model(df):
    """Run mixed effects model analysis."""
    print(f"\n[bold blue]Mixed Effects Model Results[/bold blue]")

    # Prepare data with proper categorical variable handling
    from src.utils.fix_categorical_variables import prepare_data_for_mixed_effects

    # Initial prep
    df_model = df.copy()
    df_model, valid_groups = filter_groups_by_size(df_model, "conversation_id", min_size=10)  # SAME as main model

    # Use the SAME data preparation function as the main mixed effects model
    categorical_cols = ["probing_type", "conversation_nature", "goal_relevant"]
    df_model, processing_info = prepare_data_for_mixed_effects(df_model, group_col="conversation_id", categorical_cols=categorical_cols, min_category_count=10, min_group_size=10)  # SAME as main model  # SAME as main model

    continuous_vars = ["response_length", "num_themes"]  # Removed problematic variables causing singularity
    df_model, _ = scale_columns(df_model, continuous_vars)
    print(f"using {len(df_model)} pairs from {df_model['conversation_id'].nunique()} conversations")
    model_formula = "response_depth ~ C(probing_type) + C(conversation_nature) + C(goal_relevant) + response_length + num_themes"
    needed_cols = ["response_depth", "probing_type", "conversation_nature", "goal_relevant", "response_length", "num_themes", "conversation_id"]
    df_model = df_model.dropna(subset=needed_cols).reset_index(drop=True)

    # Handle NaN values in categorical columns
    for col in ["probing_type", "conversation_nature", "goal_relevant"]:
        if col in df_model.columns:
            nan_count = df_model[col].isna().sum()
            if nan_count > 0:
                print(f"Filling {nan_count} NaN values in '{col}' with 'Unknown'")
                df_model[col] = df_model[col].fillna("Unknown")

    df_model = df_model.sort_values("conversation_id").reset_index(drop=True)
    print(f"Final modeling data: {len(df_model)} observations")
    print(f"using formula: {model_formula}")
    mixed_model = smf.mixedlm(model_formula, df_model, groups=df_model["conversation_id"])
    result = mixed_model.fit(method="bfgs", maxiter=3000)
    print(result.summary())

    # Extract probing type effects
    probing_effects = {}
    ci = result.conf_int()
    for param in result.params.index:
        if param.startswith("C(probing_type)[T."):
            probing_type = param.replace("C(probing_type)[T.", "").replace("]", "")
            probing_effects[probing_type] = {"coefficient": result.params[param], "p_value": result.pvalues[param], "conf_low": ci.loc[param, 0], "conf_high": ci.loc[param, 1]}

    if probing_effects:
        print(f"\nProbing Type Effects (vs. Reference):")
        for probing_type, effect_stats in sorted(probing_effects.items(), key=lambda x: x[1]["coefficient"], reverse=True):
            sig_level, _ = get_significance_info(effect_stats["p_value"])
            direction = "increases" if effect_stats["coefficient"] > 0 else "decreases"
            print(f"• {probing_type}: {direction} depth by {abs(effect_stats['coefficient']):.3f} {sig_level} (p={effect_stats['p_value']:.3f})")

    return result


def run_statistical_analysis(df):
    """Run complete statistical analysis including ANOVA and mixed effects."""
    print(f"\nStatistical Analysis")
    f_stat, p_value = run_anova_test(df)
    model_result = run_mixed_effects_model(df)

    return {"anova": {"f_stat": f_stat, "p_value": p_value}, "mixed_model": model_result}
