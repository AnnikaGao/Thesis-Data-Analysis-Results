"""Utilities for analysis, split into focused modules.

This package re-exports commonly used helpers to preserve
existing imports like `from src.analysis.utils import ...`.
"""

from .loaders import load_all_conversations
from .preprocess import scale_columns, filter_groups_by_size
from .stats import get_significance_info, print_significance_legend, calculate_effectiveness_metrics
from .pairs import create_probing_response_pairs
from .datasets import build_interviewee_depths_dataframe
from .normalizers import normalize_probing_type

__all__ = [
    "load_all_conversations",
    "scale_columns",
    "filter_groups_by_size",
    "get_significance_info",
    "print_significance_legend",
    "calculate_effectiveness_metrics",
    "create_probing_response_pairs",
    "build_interviewee_depths_dataframe",
    "normalize_probing_type",
]
