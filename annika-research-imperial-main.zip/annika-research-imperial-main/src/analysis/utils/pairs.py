from typing import List
import pandas as pd
from rich import print

from src.parsers import Script as Conversation
from .normalizers import normalize_probing_type


def _normalize_speaker_label(raw_label: str) -> str:
    label = str(raw_label).strip().lower()
    if label in ["interviewer", "moderator", "agent", "system", "bot"]:
        return "interviewer"
    if label in ["interviewee", "participant", "user", "human"]:
        return "interviewee"
    return label


def create_probing_response_pairs(conversations: List[Conversation], min_obs: int = 0) -> pd.DataFrame:
    """Link interviewer probing types to the next interviewee response depth."""

    def valid_parts(parts):
        cleaned = [str(p).strip() for p in parts if p]
        return [p for p in cleaned if p not in ["N/A", "", "n/a", "NA", "nan"] and len(p) > 2 and not p.isdigit()]

    def dedupe_and_filter(types):
        keep = []
        seen = set()
        for t in types:
            if t in {"Open-ended Question", "Attention Check", "Clarification"}:
                continue
            if t in seen:
                continue
            seen.add(t)
            keep.append(t)
        return keep

    pairs = []
    all_types = set()

    for conv in conversations:
        messages = conv.rounds
        for i, msg in enumerate(messages):
            if _normalize_speaker_label(msg.speaker) != "interviewer":
                continue
            if not msg.probing_type:
                continue
            vals = valid_parts(list(msg.probing_type))
            if not vals:
                continue
            normalized = dedupe_and_filter([normalize_probing_type(v) for v in vals])
            if not normalized:
                continue
            all_types.update(normalized)

            j = next((k for k in range(i + 1, min(i + 6, len(messages))) if _normalize_speaker_label(messages[k].speaker) == "interviewee"), None)
            if j is None:
                continue
            nxt = messages[j]
            for pt in normalized:
                pairs.append(
                    {
                        "conversation_id": conv.id,
                        "conversation_nature": conv.nature,
                        "probing_type": pt,
                        "response_depth": nxt.depth,
                        "probing_message": msg.transcript,
                        "response_message": nxt.transcript,
                        "probing_length": len(msg.transcript),
                        "response_length": len(nxt.transcript),
                        "goal_relevant": nxt.goal_relevant,
                        "num_goal_mappings": len(nxt.goal_mapping) if nxt.goal_mapping else 0,
                        "num_themes": len(nxt.themes) if nxt.themes else 0,
                        "message_gap": j - i,
                        "all_probing_types": ": ".join(normalized),
                    }
                )

    df = pd.DataFrame(pairs)
    if len(df) == 0:
        print("[red]No probing-response pairs found![/red]")
        return df

    if min_obs and min_obs > 1:
        type_counts = df["probing_type"].value_counts()
        valid_types = type_counts[type_counts >= min_obs].index
        df = df[df["probing_type"].isin(valid_types)].copy()
    df["response_depth"] = pd.to_numeric(df["response_depth"], errors="coerce")
    print(f"[blue]Probing types: {sorted(list(all_types))}[/blue]")
    print(f"[green]Created {len(df)} probing-response pairs with {df['probing_type'].nunique()} probing types[/green]")
    return df
