from typing import List, Tuple
import numpy as np
import pandas as pd
import scipy.stats as stats
from statsmodels.stats.multitest import multipletests


def get_significance_info(p_value: float) -> Tuple[str, str]:
    """Map p-values to asterisks and rich color tags."""
    match p_value:
        case _ if p_value < 0.001:
            return "***", "bold red"
        case _ if p_value < 0.01:
            return "**", "red"
        case _ if p_value < 0.05:
            return "*", "yellow"
        case _:
            return "n.s.", "dim"


def print_significance_legend() -> None:
    from rich import print

    print(f"\n[bold blue]Significance Levels:[/bold blue]")
    print("*** p < 0.001 (highly significant)")
    print("**  p < 0.01  (very significant)")
    print("*   p < 0.05  (significant)")
    print("n.s. p ≥ 0.05 (not significant)")
    print("P-values compare each probing type against all other types (Welch t-test with FDR).")


def calculate_effectiveness_metrics(df: pd.DataFrame, min_n_for_test: int = 5) -> pd.DataFrame:
    """Aggregate effectiveness stats by probing_type and compute Welch tests vs. complement with FDR."""
    df_valid = df.dropna(subset=["response_depth"]).copy()
    effectiveness = (
        df_valid.groupby("probing_type")
        .agg(
            {
                "response_depth": ["count", "mean", "std", "median", "min", "max"],
                "response_length": "mean",
                "message_gap": "mean",
            }
        )
        .round(3)
    )
    effectiveness.columns = [
        "count",
        "mean_depth",
        "std_depth",
        "median_depth",
        "min_depth",
        "max_depth",
        "avg_response_length",
        "avg_gap",
    ]
    effectiveness = effectiveness.sort_values("mean_depth", ascending=False)

    p_values: List[float] = []
    effect_sizes: List[float] = []
    for probing_type in effectiveness.index:
        group_a = df_valid[df_valid["probing_type"] == probing_type]["response_depth"].values
        group_b = df_valid[df_valid["probing_type"] != probing_type]["response_depth"].values
        if len(group_a) >= max(2, min_n_for_test) and len(group_b) >= 2:
            _t, p_val = stats.ttest_ind(group_a, group_b, equal_var=False, nan_policy="omit")
            p_values.append(p_val if not pd.isna(p_val) else float("nan"))
            na, nb = len(group_a), len(group_b)
            sa2, sb2 = pd.Series(group_a).var(ddof=1), pd.Series(group_b).var(ddof=1)
            denom_df = na + nb - 2
            if denom_df > 0 and sa2 >= 0 and sb2 >= 0:
                s_pooled = ((na - 1) * sa2 + (nb - 1) * sb2) / denom_df
                s_pooled = s_pooled**0.5 if s_pooled > 0 else float("nan")
            else:
                s_pooled = float("nan")
            if s_pooled and s_pooled > 0:
                cohen_d = (pd.Series(group_a).mean() - pd.Series(group_b).mean()) / s_pooled
                J = 1 - (3 / (4 * (na + nb) - 9)) if (na + nb) > 2 else 1.0
                hedges_g = cohen_d * J
            else:
                hedges_g = float("nan")
            effect_sizes.append(hedges_g)
        else:
            p_values.append(float("nan"))
            effect_sizes.append(float("nan"))
    effectiveness["p_value"] = p_values
    effectiveness["hedges_g"] = effect_sizes

    pvals = effectiveness["p_value"].values
    mask = ~pd.isna(pvals)
    p_adj = np.full_like(pvals, fill_value=np.nan, dtype=float)
    if mask.sum() > 0:
        _, p_adj_valid, _, _ = multipletests(pvals[mask], method="fdr_bh")
        p_adj[mask] = p_adj_valid
    effectiveness["p_adj"] = p_adj
    return effectiveness
