from pathlib import Path
from typing import List
from rich import print

from src.parsers import Script as Conversation
from src.parsers import load_all_scripts


def load_all_conversations() -> List[Conversation]:
    """Load all scripts (conversations) using the unified cached loader."""
    conversations: List[Conversation] = list(load_all_scripts(Path("data"), ("human", "ai")))
    for conv in conversations:
        _ = len(getattr(conv, "rounds", []))  # warm cache and verify readable
        print(f"Loaded {conv.nature} conversation {conv.id} with {len(getattr(conv, 'rounds', []))} messages")
    return conversations
