import re


def normalize_probing_type(probing_type: str) -> str:
    """Normalize probing type strings to reduce redundancies and unify separators.

    - Fix common typos (e.g., "Vebral Encouragement" → "Verbal Encouragement")
    - Unify synonyms (e.g., "Open" → "Open-ended Question")
    - Standardize composite separators to ':' without spaces
    """
    normalized = re.sub(r"\s+", " ", str(probing_type).strip())
    normalized = re.sub(r"\s*[:/;,\|]+\s*", ":", normalized)
    key = normalized.lower()

    whole_mapping = {
        # verbal agreement variants
        "verbal agreement": "Verbal Encouragement",
        "verbal aggrement": "Verbal Encouragement",
        "verbal agrrement": "Verbal Encouragement",
        "veral agreement": "Verbal Encouragement",
        "veral agrrement": "Verbal Encouragement",
        "verbal ag": "Verbal Encouragement",
        "vegree agreement": "Verbal Encouragement",
        # verbal encouragement variants
        "verbal encouragement": "Verbal Encouragement",
        "vebral encouragement": "Verbal Encouragement",
        "verbal ecouragement": "Verbal Encouragement",
        "verbal encouragment": "Verbal Encouragement",
        "verbal encourgement": "Verbal Encouragement",
        "vebral encourgement": "Verbal Encouragement",
        "verbal encourage": "Verbal Encouragement",
        "vebral encouragment": "Verbal Encouragement",
        # explanation typo
        "expanation": "Explanation",
        # open-ended
        "open-ended question": "Open-ended Question",
        "open ended question": "Open-ended Question",
        "open question": "Open-ended Question",
        "open": "Open-ended Question",
        # Direct mappings
        "echo": "Echo",
        "expansion": "Expansion",
        "explanation": "Explanation",
        "clarification": "Clarification",
        "leading": "Leading",
        "bonding": "Bonding",
        "attention check": "Attention Check",
        "wait time": "Wait Time",
    }

    if key in whole_mapping:
        return whole_mapping[key]

    # For composite labels, normalize each component
    if ":" in normalized:
        parts = [p for p in normalized.split(":") if p]
        normalized_parts = []
        for part in parts:
            pkey = part.lower().strip()
            mapped = whole_mapping.get(pkey)
            if mapped:
                normalized_parts.append(mapped)
            else:
                normalized_parts.append(part if part.isupper() else part.title())
        return ":".join(normalized_parts)

    # Preserve acronyms or strings with non-alpha characters (e.g., AI)
    if normalized.isupper() or any(not ch.isalpha() and not ch.isspace() for ch in normalized):
        return normalized

    return normalized.title()
