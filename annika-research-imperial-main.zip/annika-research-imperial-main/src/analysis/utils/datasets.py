from typing import List
import pandas as pd
from src.parsers import Script as Conversation


def build_interviewee_depths_dataframe(conversations: List[Conversation]) -> pd.DataFrame:
    """Construct a DataFrame of interviewee messages' depths using the shared parser.

    Returns a DataFrame with columns: conversation_id, conversation_nature, depth
    Includes zero depths; drops NA depths to align with statistical usage.
    """
    rows = []
    for conv in conversations:
        for msg in getattr(conv, "rounds", []):
            if str(getattr(msg, "speaker", "")).strip().lower() == "interviewee":
                val = getattr(msg, "depth", None)
                if pd.notna(val):
                    rows.append(
                        {
                            "conversation_id": conv.id,
                            "conversation_nature": conv.nature,
                            "depth": float(val),
                        }
                    )
    return pd.DataFrame(rows)
