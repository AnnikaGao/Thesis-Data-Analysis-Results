from typing import Iterable, Tuple
import pandas as pd
from sklearn.preprocessing import StandardScaler


def scale_columns(df: pd.DataFrame, columns: Iterable[str]) -> Tuple[pd.DataFrame, StandardScaler]:
    """Fill NA with 0 and standardize selected columns; returns modified df and scaler."""
    scaler = StandardScaler()
    for col in columns:
        df[col] = df[col].fillna(0)
    df[list(columns)] = scaler.fit_transform(df[list(columns)])
    return df, scaler


def filter_groups_by_size(df: pd.DataFrame, group_col: str, min_size: int):
    """Filter dataframe to groups with at least min_size observations; return filtered df and valid group index."""
    group_sizes = df.groupby(group_col).size()
    valid_groups = group_sizes[group_sizes >= min_size].index
    return df[df[group_col].isin(valid_groups)], valid_groups
