#!/Users/donyin/miniconda3/bin/python
"""Visualization aggregator that composes subplot modules from src.analysis.plots."""

import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path

from .plots import setup_plot_style
from .plots.mean_depth_comparison import create_mean_depth_comparison
from .plots.box_depth_distribution import create_box_plot_distributions, create_box_plot_distributions_counts
from .plots.sample_size_breakdown import create_sample_size_breakdown
from .plots.heatmap_depth_by_nature import create_heatmap_depth_by_nature
from .plots.length_vs_depth_scatter import create_scatter_length_vs_depth
from .plots.human_ai_distribution_pie import create_human_ai_distribution_pie
from .plots.goal_relevance_impact import create_goal_relevance_impact
from .plots.depth_distribution_histogram import create_depth_distribution_histogram
from .plots.message_gap_analysis import create_message_gap_analysis


def create_comprehensive_visualization(df, effectiveness, depths_df=None):
    """Create the complete visualization with nine subplots in a 3x3 grid."""
    setup_plot_style()
    fig, axes = plt.subplots(3, 3, figsize=(22, 16))
    ax_list = axes.ravel()

    create_mean_depth_comparison(df, effectiveness, ax_list[0])
    create_box_plot_distributions(df, effectiveness, ax_list[1])
    create_sample_size_breakdown(df, effectiveness, ax_list[2])
    create_heatmap_depth_by_nature(df, effectiveness, ax_list[3])
    create_scatter_length_vs_depth(df, effectiveness, ax_list[4])
    create_human_ai_distribution_pie(df, ax_list[5])
    create_goal_relevance_impact(df, effectiveness, ax_list[6])
    create_message_gap_analysis(df, effectiveness, ax_list[7])
    if depths_df is None:
        # Backward-compat: derive depths_df from df if not provided
        import pandas as pd

        if "response_depth" in df.columns:
            depths_df = pd.DataFrame(
                {
                    "conversation_nature": df["conversation_nature"],
                    "depth": df["response_depth"],
                }
            )
        else:
            depths_df = df.rename(columns={"response_depth": "depth"})
    create_depth_distribution_histogram(depths_df, ax_list[8])

    plt.tight_layout()
    results_dir = Path("results")
    results_dir.mkdir(parents=True, exist_ok=True)
    out_path = results_dir / "probing_effectiveness_analysis.png"
    plt.savefig(out_path, dpi=300, bbox_inches="tight")
    print(f"[green]Comprehensive visualization saved as '{out_path}'[/green]")

    # Export each subplot as individual images by re-rendering
    imgs_dir = results_dir / "imgs"
    imgs_dir.mkdir(parents=True, exist_ok=True)
    exporters = [
        ("mean_depth_comparison", lambda ax: create_mean_depth_comparison(df, effectiveness, ax)),
        ("box_depth_distribution", lambda ax: create_box_plot_distributions(df, effectiveness, ax)),
        ("box_depth_distribution_counts", lambda ax: create_box_plot_distributions_counts(df, effectiveness, ax)),
        ("sample_size_breakdown", lambda ax: create_sample_size_breakdown(df, effectiveness, ax)),
        ("heatmap_depth_by_nature", lambda ax: create_heatmap_depth_by_nature(df, effectiveness, ax)),
        ("length_vs_depth_scatter", lambda ax: create_scatter_length_vs_depth(df, effectiveness, ax)),
        ("human_ai_distribution_pie", lambda ax: create_human_ai_distribution_pie(df, ax)),
        ("goal_relevance_impact", lambda ax: create_goal_relevance_impact(df, effectiveness, ax)),
        ("message_gap_analysis", lambda ax: create_message_gap_analysis(df, effectiveness, ax)),
        ("depth_distribution_histogram", lambda ax: create_depth_distribution_histogram(depths_df, ax)),
    ]
    for name, render in exporters:
        sub_fig, sub_ax = plt.subplots(figsize=(8, 6))
        render(sub_ax)
        sub_out = imgs_dir / f"{name}.png"
        sub_fig.tight_layout()
        sub_fig.savefig(sub_out, dpi=300, bbox_inches="tight")
        plt.close(sub_fig)
    print(f"[green]Saved individual subplot images in '{imgs_dir}'[/green]")

    return fig
