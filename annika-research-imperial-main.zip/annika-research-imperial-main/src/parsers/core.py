from __future__ import annotations

import pandas as pd
from pathlib import Path
from functools import cached_property
from typing import Iterable, List, Literal, Optional


class Round:
    """A single dialogue round within a script (one CSV row).

    Exposes normalized accessors for commonly used columns.
    """

    def __init__(self, parent_script: "Script", row_data: pd.Series):
        self.parent_script = parent_script
        self._data = row_data

    # --- Canonical accessors ---
    @property
    def start(self) -> str:
        return str(self._data.get("Start", ""))

    @property
    def end(self) -> str:
        return str(self._data.get("End", ""))

    @property
    def speaker(self) -> str:
        return str(self._data.get("Speaker", ""))

    @property
    def transcript(self) -> str:
        val = self._data.get("Transcript", "")
        if pd.isna(val):
            return ""
        return str(val)

    @property
    def mapped_q(self) -> str:
        return str(self._data.get("Mapped Q#", ""))

    @property
    def goal_relevant(self) -> bool:
        return str(self._data.get("Goal Relevant?", "")).strip().lower() == "yes"

    @staticmethod
    def _split_to_list(value: str, seps: Iterable[str]) -> List[str]:
        if not value:
            return []
        for sep in seps:
            if sep in value:
                return [x.strip() for x in value.split(sep) if x.strip()]
        return [value.strip()] if value.strip() else []

    @property
    def goal_mapping(self) -> List[str]:
        val = str(self._data.get("Goal Mapping", ""))
        return self._split_to_list(val, [";", ","])  # type: ignore[arg-type]

    @property
    def purpose_if_irrelevant(self) -> List[str]:
        val = str(self._data.get("Purpose if Irrelevant", ""))
        return self._split_to_list(val, ["/", ";", ","])  # type: ignore[arg-type]

    @property
    def themes(self) -> List[str]:
        val = str(self._data.get("Theme(s)", ""))
        return self._split_to_list(val, ["/", ";", ","])  # type: ignore[arg-type]

    @property
    def probing_type(self) -> List[str]:
        val = str(self._data.get("Probing Type", ""))
        return self._split_to_list(val, [":", "/", ";", ","])  # type: ignore[arg-type]

    @property
    def depth(self) -> float:
        sval = str(self._data.get("Depth", "")).strip()
        return pd.to_numeric(pd.Series([sval]), errors="coerce").iloc[0]


class Script:
    """Represents a single CSV transcript file with multiple rounds."""

    def __init__(self, file_path: Path):
        self.file_path = Path(file_path)

    @cached_property
    def rounds(self) -> List[Round]:
        # robust decoding without try/except: tolerate invalid bytes
        df = pd.read_csv(self.file_path, encoding="utf-8-sig", encoding_errors="replace")
        return [Round(self, row) for _, row in df.iterrows()]

    # Backwards-compatible alias used in legacy code
    @property
    def messages(self) -> List[Round]:
        return self.rounds

    @property
    def nature(self) -> Literal["human", "ai"]:
        return "human" if "/human/" in str(self.file_path) or "/human\\" in str(self.file_path) else "ai"

    @property
    def id(self) -> str:
        return self.file_path.stem.split("_")[0]

    @property
    def total_word_count(self) -> int:
        return sum(len(round.transcript.split()) for round in self.rounds)

    @property
    def session_time_length(self) -> float:
        """taking the time of the last row: e.g., `48:12.4`"""
        last_row = self.rounds[-1]
        end_time = last_row.end
        minutes = float(end_time.split(":")[0])
        seconds = float(end_time.split(":")[1])
        return minutes + seconds / 60


# --- Loading utilities with simple caches to avoid re-reading files ---
_SCRIPT_INSTANCE_CACHE: dict[str, Script] = {}


def _get_or_create_script(path: Path) -> Script:
    key = str(Path(path).resolve())
    cached = _SCRIPT_INSTANCE_CACHE.get(key)
    if cached is not None:
        return cached
    script = Script(Path(path))
    _SCRIPT_INSTANCE_CACHE[key] = script
    return script


def load_scripts_from_dirs(directories: Iterable[Path]) -> List[Script]:
    scripts: List[Script] = []
    for directory in directories:
        for csv_file in sorted(Path(directory).glob("*.csv")):
            scripts.append(_get_or_create_script(csv_file))
    return scripts


def load_all_scripts(data_root: Optional[Path | str] = "data", subdirs: Iterable[str] = ("human", "ai")) -> List[Script]:
    root = Path(data_root) if data_root is not None else Path("data")
    dirs = [root / sd for sd in subdirs]
    return load_scripts_from_dirs(dirs)
