#!/usr/bin/env python3
"""
Utility functions to fix categorical variable issues that cause convergence problems.
This module provides functions to consolidate sparse categories and improve model stability.
"""

import pandas as pd
from typing import Dict, List, Tuple


def consolidate_sparse_categories(df: pd.DataFrame, column: str, min_count: int = 0, other_name: str = "Other") -> pd.DataFrame:
    """
    Consolidate categories with fewer than min_count observations into 'Other' category.

    Args:
        df: DataFrame containing the categorical column
        column: Name of the categorical column to consolidate
        min_count: Minimum number of observations required to keep a category
        other_name: Name for the consolidated category

    Returns:
        DataFrame with consolidated categories
    """
    if column not in df.columns:
        return df

    df_copy = df.copy()
    value_counts = df_copy[column].value_counts()
    sparse_categories = value_counts[value_counts < min_count].index.tolist()

    if len(sparse_categories) > 0:
        print(f"Consolidating {len(sparse_categories)} sparse categories in '{column}' (< {min_count} obs) into '{other_name}'")
        df_copy[column] = df_copy[column].replace(sparse_categories, other_name)
        new_counts = df_copy[column].value_counts()
        print(f"New category distribution:")
        for category, count in new_counts.head(10).items():
            print(f"  - {category}: {count}")

        if len(new_counts) > 10:
            print(f"  ... and {len(new_counts) - 10} more categories")

    return df_copy


def simplify_probing_types(probing_type: str) -> str:
    """
    Simplify complex probing type strings into main categories.

    Args:
        probing_type: Original probing type string

    Returns:
        Simplified probing type category
    """
    if pd.isna(probing_type) or not probing_type or probing_type.strip() == "":
        return "None"

    probing_type = str(probing_type).lower().strip()

    # Define main categories and their keywords
    category_mapping = {
        "Echo": ["echo"],
        "Verbal Agreement": ["verbal agreement", "verbal agrrement", "veral agreement", "vegree agreement"],
        "Expansion": ["expansion"],
        "Explanation": ["explanation"],
        "Leading": ["leading"],
        "Clarification": ["clarification", "clarifying"],
        "Follow-up": ["follow-up", "follow up"],
        "Probing": ["probing"],
    }

    # Check for combined categories (e.g., "Echo; Verbal Agreement")
    if ";" in probing_type:
        # Split and take the first main category
        parts = [p.strip() for p in probing_type.split(";")]
        probing_type = parts[0] if parts else probing_type

    # Map to main categories
    for main_category, keywords in category_mapping.items():
        for keyword in keywords:
            if keyword in probing_type:
                return main_category

    # If no match found, return simplified version
    return probing_type.title()


def prepare_data_for_mixed_effects(df: pd.DataFrame, group_col: str = "conversation_id", categorical_cols: List[str] = None, min_category_count: int = 0, min_group_size: int = 5) -> Tuple[pd.DataFrame, Dict]:
    """
    Prepare data for mixed effects modeling by addressing common convergence issues.

    Args:
        df: Input dataframe
        group_col: Column name for grouping variable
        categorical_cols: List of categorical columns to process
        min_category_count: Minimum observations per category
        min_group_size: Minimum observations per group

    Returns:
        Tuple of (processed_dataframe, processing_info)
    """
    df_processed = df.copy()
    processing_info = {}

    # Default categorical columns if not specified
    if categorical_cols is None:
        categorical_cols = df_processed.select_dtypes(include=["object", "category"]).columns.tolist()
        if group_col in categorical_cols:
            categorical_cols.remove(group_col)

    print(f"Preparing data for mixed effects modeling...")
    print(f"Original data: {len(df_processed)} observations")

    # 1. Handle missing values in key columns
    if "depth" in df_processed.columns:
        df_processed = df_processed.dropna(subset=["depth"])
        print(f"After removing missing depth values: {len(df_processed)} observations")
    elif "response_depth" in df_processed.columns:
        df_processed = df_processed.dropna(subset=["response_depth"])
        print(f"After removing missing response_depth values: {len(df_processed)} observations")

    # 2. Simplify probing types if present
    if "probing_type" in df_processed.columns:
        print(f"Simplifying probing types...")
        df_processed["probing_type"] = df_processed["probing_type"].apply(simplify_probing_types)
        processing_info["probing_type_simplified"] = True

    # 3. Consolidate sparse categories
    for col in categorical_cols:
        if col in df_processed.columns:
            original_categories = df_processed[col].nunique()
            df_processed = consolidate_sparse_categories(df_processed, col, min_category_count)
            new_categories = df_processed[col].nunique()
            processing_info[f"{col}_categories_before"] = original_categories
            processing_info[f"{col}_categories_after"] = new_categories

    # 4. Filter groups by minimum size
    if group_col in df_processed.columns:
        group_sizes = df_processed.groupby(group_col).size()
        valid_groups = group_sizes[group_sizes >= min_group_size].index
        df_processed = df_processed[df_processed[group_col].isin(valid_groups)]

        print(f"After filtering groups (min size {min_group_size}): {len(df_processed)} observations from {len(valid_groups)} groups")
        processing_info["groups_before"] = len(group_sizes)
        processing_info["groups_after"] = len(valid_groups)

    # 5. Check final data quality
    if group_col in df_processed.columns:
        final_group_sizes = df_processed.groupby(group_col).size()
        processing_info["final_group_size_mean"] = final_group_sizes.mean()
        processing_info["final_group_size_std"] = final_group_sizes.std()

        # Check ICC estimate
        outcome_col = "depth" if "depth" in df_processed.columns else "response_depth"
        if outcome_col in df_processed.columns:
            group_means = df_processed.groupby(group_col)[outcome_col].mean()
            total_var = df_processed[outcome_col].var()
            between_var = group_means.var()
            estimated_icc = between_var / total_var if total_var > 0 else 0
            processing_info["estimated_icc"] = estimated_icc

            print(f"Final data quality:")
            print(f"  - {len(df_processed)} observations from {len(valid_groups)} groups")
            print(f"  - Mean group size: {final_group_sizes.mean():.1f} (std: {final_group_sizes.std():.1f})")
            print(f"  - Estimated Intraclass Correlation Coefficient (ICC): {estimated_icc:.3f}")

    return df_processed, processing_info
