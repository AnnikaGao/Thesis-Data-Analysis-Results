#!/Users/donyin/miniconda3/bin/python
"""
Analyze column values in CSV files and create pie plots for each column.
Creates separate plots for AI and human data.
"""

from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from collections import Counter
import warnings
from donware import banner

warnings.filterwarnings("ignore")


def load_csv_with_encoding(csv_file):
    """Load CSV file with proper encoding handling."""
    return pd.read_csv(csv_file, encoding="utf-8-sig", encoding_errors="replace", on_bad_lines="skip")


def load_all_data(data_type):
    """Load all CSV files from either 'ai' or 'human' directory."""
    base_dir = Path(__file__).parent
    data_dir = base_dir / "data" / data_type

    all_data = []

    for csv_file in sorted(data_dir.glob("*.csv")):
        df = load_csv_with_encoding(csv_file)
        df["source_file"] = csv_file.name
        all_data.append(df)

    return pd.concat(all_data, ignore_index=True) if all_data else pd.DataFrame()


def clean_value(value):
    """Clean and normalize values for analysis."""
    if pd.isna(value) or value == "" or str(value).strip() == "":
        return "N/A"

    # Convert to string and clean
    clean_val = str(value).strip()

    # Normalize common variations
    if clean_val.lower() in ["n/a", "na", "none", "null", ""]:
        return "N/A"

    return clean_val


def get_top_values(series, max_categories=10):
    """Get top N values from a series, grouping others as 'Other'."""
    value_counts = series.value_counts()

    if len(value_counts) <= max_categories:
        return value_counts

    # Keep top categories and group the rest
    top_values = value_counts.head(max_categories - 1)
    other_count = value_counts.tail(len(value_counts) - max_categories + 1).sum()

    if other_count > 0:
        top_values["Other"] = other_count

    return top_values


def create_bar_plot(data, column_name, data_type, output_dir):
    """Create a vertical bar plot for a specific column."""
    # Clean the data
    cleaned_data = data[column_name].apply(clean_value)

    # Get value counts
    value_counts = get_top_values(cleaned_data, max_categories=15)

    if len(value_counts) == 0:
        print(f"  No data found for column '{column_name}' in {data_type} data")
        return

    # Create the bar chart
    plt.figure(figsize=(12, 8))

    # Define colors
    colors = plt.cm.Set3(np.linspace(0, 1, len(value_counts)))

    # Create vertical bar chart
    bars = plt.bar(range(len(value_counts)), value_counts.values, color=colors)

    # Add value labels on top of bars
    for i, (bar, count) in enumerate(zip(bars, value_counts.values)):
        height = bar.get_height()
        percentage = (count / value_counts.sum()) * 100
        plt.text(bar.get_x() + bar.get_width() / 2.0, height + max(value_counts.values) * 0.01, f"{count}\n({percentage:.1f}%)", ha="center", va="bottom", fontsize=9, fontweight="bold")

    # Set labels and title
    plt.xlabel("Categories", fontsize=12, fontweight="bold")
    plt.ylabel("Count", fontsize=12, fontweight="bold")
    plt.title(f"{column_name} - {data_type.upper()} Data\n(Total entries: {len(cleaned_data)})", fontsize=14, fontweight="bold", pad=20)

    # Set x-axis labels with rotation for better readability
    plt.xticks(range(len(value_counts)), value_counts.index, rotation=45, ha="right")

    # Add grid for better readability
    plt.grid(axis="y", alpha=0.3, linestyle="--")

    # Adjust layout to prevent label cutoff
    plt.tight_layout()

    # Save the plot
    safe_column_name = column_name.replace("/", "_").replace("?", "").replace("#", "num").replace(" ", "_")
    filename = f"{data_type}_{safe_column_name}_bar.png"
    filepath = output_dir / filename

    plt.savefig(filepath, dpi=300, bbox_inches="tight")
    plt.close()

    print(f"  Created bar chart: {filename}")
    print(f"     Top values: {', '.join([f'{k} ({v})' for k, v in value_counts.head(3).items()])}")


def analyze_columns():
    """Analyze all columns and create bar plots."""
    print("Starting column value analysis...")
    banner("-")

    # Create output directory
    base_dir = Path(__file__).parent
    output_dir = base_dir / "column_analysis_bar_plots"
    output_dir.mkdir(exist_ok=True)

    # Load data
    print("\n📁 Loading data...")
    ai_data = load_all_data("ai")
    human_data = load_all_data("human")

    if ai_data.empty and human_data.empty:
        print("No data found in either ai or human directories")
        return

    print(f"  AI data: {len(ai_data)} rows from {ai_data['source_file'].nunique() if not ai_data.empty else 0} files")
    print(f"  Human data: {len(human_data)} rows from {human_data['source_file'].nunique() if not human_data.empty else 0} files")

    # Get common columns (excluding source_file)
    ai_columns = set(ai_data.columns) - {"source_file"} if not ai_data.empty else set()
    human_columns = set(human_data.columns) - {"source_file"} if not human_data.empty else set()
    common_columns = ai_columns.intersection(human_columns) if ai_columns and human_columns else ai_columns.union(human_columns)

    # Skip columns that are mostly unique identifiers or continuous values
    skip_columns = {"Start", "End", "Transcript"}
    analysis_columns = [col for col in common_columns if col not in skip_columns]

    print(f"\nAnalyzing {len(analysis_columns)} columns: {', '.join(analysis_columns)}")
    print("-" * 60)

    # Create plots for each data type and column
    for data_type, data in [("ai", ai_data), ("human", human_data)]:
        if data.empty:
            print(f"\nSkipping {data_type} data - no files found")
            continue

        print(f"\nCreating plots for {data_type.upper()} data:")

        for column in sorted(analysis_columns):
            if column in data.columns:
                create_bar_plot(data, column, data_type, output_dir)
            else:
                print(f"  Column '{column}' not found in {data_type} data")

    print("\n" + "=" * 60)
    print(f"Analysis complete!")
    print(f"   Plots saved to: {output_dir}")
    print(f"   Total plots created: {len(list(output_dir.glob('*.png')))}")


def create_summary_report():
    """Create a summary report of column value distributions."""
    print("\n📋 Creating summary report...")

    # Load data
    ai_data = load_all_data("ai")
    human_data = load_all_data("human")

    base_dir = Path(__file__).parent
    report_file = base_dir / "column_analysis_report.txt"

    with open(report_file, "w", encoding="utf-8") as f:
        f.write("Column Value Analysis Report\n")
        f.write("=" * 50 + "\n\n")

        for data_type, data in [("AI", ai_data), ("Human", human_data)]:
            if data.empty:
                continue

            f.write(f"{data_type} Data Analysis\n")
            f.write("-" * 30 + "\n")
            f.write(f"Total rows: {len(data)}\n")
            f.write(f"Source files: {data['source_file'].nunique()}\n\n")

            # Analyze each column
            skip_columns = {"Start", "End", "Transcript", "source_file"}
            for column in sorted(data.columns):
                if column in skip_columns:
                    continue

                cleaned_data = data[column].apply(clean_value)
                value_counts = cleaned_data.value_counts().head(10)

                f.write(f"{column}:\n")
                f.write(f"  Unique values: {cleaned_data.nunique()}\n")
                f.write(f"  Most common values:\n")
                for value, count in value_counts.items():
                    percentage = (count / len(cleaned_data)) * 100
                    f.write(f"    {value}: {count} ({percentage:.1f}%)\n")
                f.write("\n")

            f.write("\n")

    print(f"  Summary report saved: {report_file}")


if __name__ == "__main__":
    analyze_columns()
    create_summary_report()
