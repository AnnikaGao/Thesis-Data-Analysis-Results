#!/Users/donyin/miniconda3/bin/python
"""
Check column name consistency across all CSV files in data/ai/ and data/human/ directories.
Print out any mismatches found.
"""

from pathlib import Path
import pandas as pd


def get_csv_columns(csv_file):
    """Get column names from a CSV file."""
    df = pd.read_csv(csv_file, encoding="utf-8-sig", encoding_errors="replace", on_bad_lines="skip")
    return list(df.columns)


def check_column_consistency():
    """Check that all CSV files have consistent column names."""
    base_dir = Path(__file__).parent
    data_dir = base_dir / "data"

    ai_dir = data_dir / "ai"
    human_dir = data_dir / "human"

    # Collect all CSV files and their columns
    all_files = {}
    reference_columns = None
    reference_file = None

    # Process AI files
    for csv_file in ai_dir.glob("*.csv"):
        columns = get_csv_columns(csv_file)
        all_files[csv_file] = columns

        if reference_columns is None:
            reference_columns = columns
            reference_file = csv_file

    # Process Human files
    for csv_file in human_dir.glob("*.csv"):
        columns = get_csv_columns(csv_file)
        all_files[csv_file] = columns

        if reference_columns is None:
            reference_columns = columns
            reference_file = csv_file

    print(f"Column consistency check across {len(all_files)} CSV files")

    if reference_file is None:
        print("No CSV files found in data/ai/ or data/human/ directories")
        return False

    print(f"Reference file: {reference_file.name}")
    print(f"Reference columns ({len(reference_columns)}): {reference_columns}")
    print("-" * 80)

    # Check for mismatches
    mismatches_found = False

    for csv_file, columns in all_files.items():
        if columns != reference_columns:
            mismatches_found = True
            print(f"\nMISMATCH: {csv_file.name}")
            print(f"   Expected: {reference_columns}")
            print(f"   Found:    {columns}")

            # Show differences
            missing_cols = set(reference_columns) - set(columns)
            extra_cols = set(columns) - set(reference_columns)

            if missing_cols:
                print(f"   Missing:  {list(missing_cols)}")
            if extra_cols:
                print(f"   Extra:    {list(extra_cols)}")
        else:
            print(f"{csv_file.name} - columns match")

    if not mismatches_found:
        print("\nAll CSV files have consistent column names!")
    else:
        print(f"\nFound mismatches in column names!")

    return not mismatches_found


if __name__ == "__main__":
    check_column_consistency()
