#!/Users/donyin/miniconda3/bin/python
"""
Clean CSV files by removing 'Unnamed' columns and fixing column name inconsistencies.
This script will modify the original files in place.
"""

from pathlib import Path
import pandas as pd
from donware import banner


def load_csv_with_encoding(csv_file):
    """Load CSV file with proper encoding handling."""
    return pd.read_csv(csv_file, encoding="utf-8-sig", encoding_errors="replace", on_bad_lines="skip")


def clean_csv_columns(df):
    """Clean DataFrame by removing Unnamed columns and fixing column names."""
    columns_to_keep = [col for col in df.columns if not str(col).startswith("Unnamed:")]
    df_cleaned = df[columns_to_keep].copy()
    column_mapping = {"Research Aim Mapping": "Goal Mapping", "Research Aim Relevant?": "Goal Relevant?", "Probing Type ": "Probing Type", "Depth ": "Depth"}
    df_cleaned.columns = [column_mapping.get(col, col) for col in df_cleaned.columns]
    return df_cleaned


def clean_csv_file(csv_file):
    """Clean a single CSV file by removing Unnamed columns and fixing column names."""
    print(f"Processing {csv_file.name}...")

    # Load the CSV file
    df = load_csv_with_encoding(csv_file)
    original_columns = list(df.columns)

    # Clean the DataFrame
    df_cleaned = clean_csv_columns(df)
    cleaned_columns = list(df_cleaned.columns)

    # Check if any changes were made
    if original_columns != cleaned_columns:
        removed_cols = set(original_columns) - set(cleaned_columns)
        renamed_cols = []

        # Find renamed columns
        for old_col in original_columns:
            if old_col in cleaned_columns:
                continue
            if old_col.startswith("Unnamed:"):
                continue
            # Check if this column was renamed
            for new_col in cleaned_columns:
                if new_col not in original_columns and old_col in {"Research Aim Mapping": "Goal Mapping", "Research Aim Relevant?": "Goal Relevant?", "Probing Type ": "Probing Type", "Depth ": "Depth"}:
                    renamed_cols.append(f"{old_col} -> {new_col}")
                    break

        print(f"  ✨ Cleaned {csv_file.name}:")
        if removed_cols:
            unnamed_cols = [col for col in removed_cols if str(col).startswith("Unnamed:")]
            if unnamed_cols:
                print(f"    - Removed {len(unnamed_cols)} Unnamed columns")

        if renamed_cols:
            for rename in renamed_cols:
                print(f"    - Renamed: {rename}")

        # Save the cleaned DataFrame back to the original file
        df_cleaned.to_csv(csv_file, index=False, encoding="utf-8")
        print(f"  Saved cleaned file with {len(cleaned_columns)} columns")
    else:
        print(f"  {csv_file.name} - no changes needed")


def clean_all_csv_files():
    """Clean all CSV files in data/ai/ and data/human/ directories."""
    base_dir = Path(__file__).parent
    data_dir = base_dir / "data"

    ai_dir = data_dir / "ai"
    human_dir = data_dir / "human"

    print("🧹 Starting CSV cleaning process...")
    banner("-")

    files_processed = 0
    files_cleaned = 0

    # Process AI files
    print("\n📁 Processing AI files:")
    for csv_file in sorted(ai_dir.glob("*.csv")):
        original_df = load_csv_with_encoding(csv_file)
        original_col_count = len(original_df.columns)

        clean_csv_file(csv_file)

        cleaned_df = load_csv_with_encoding(csv_file)
        cleaned_col_count = len(cleaned_df.columns)

        files_processed += 1
        if original_col_count != cleaned_col_count:
            files_cleaned += 1

    # Process Human files
    print("\n📁 Processing Human files:")
    for csv_file in sorted(human_dir.glob("*.csv")):
        original_df = load_csv_with_encoding(csv_file)
        original_col_count = len(original_df.columns)

        clean_csv_file(csv_file)

        cleaned_df = load_csv_with_encoding(csv_file)
        cleaned_col_count = len(cleaned_df.columns)

        files_processed += 1
        if original_col_count != cleaned_col_count:
            files_cleaned += 1

    print("\n" + "=" * 60)
    print(f"Cleaning complete!")
    print(f"   Files processed: {files_processed}")
    print(f"   Files cleaned: {files_cleaned}")
    print(f"   Files unchanged: {files_processed - files_cleaned}")


if __name__ == "__main__":
    clean_all_csv_files()
